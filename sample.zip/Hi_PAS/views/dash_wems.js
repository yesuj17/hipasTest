﻿﻿/* WEMS Javascript */

/* OnLoad() call from index */
function wems_OnLoad() {
}
