﻿// WEMS Restful API Handler
var wemsDBManager = require('../utility/dbManager/wemsDBManager');

// GET Restful API Handler
module.exports.getAnalysisData = function (req, res) {
    if (!wemsDBManager) {
        return;
    }

    var period = req.params.parameter;
    var cycleMonitoringDats = wemsDBManager.getCycleMonitoringData(period);
    calPowerData(cycleMonitorinDatas);
}

// POST Restful API Handler
// PUT Restful API Handler
// DELETE Restful API Handler

// WEMS Method
function calPowerData(cycleMonitorinData) {
    return;
}
