﻿/* Machine Agent Restful API Handler */
module.exports.updateMachineConfig = function (req, res) {

}

module.exports.addMachineRealTimeData = function (req, res) {

}

module.exports.addMachineCycleData = function (req, res) {

}

module.exports.addMachineErrorData = function (req, res) {

}