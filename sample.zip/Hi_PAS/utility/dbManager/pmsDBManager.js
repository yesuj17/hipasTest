﻿var mongoose = require('mongoose');
var generateSchema = require('generate-schema');

// Insert to Mongo DB
// Update to Mongo DB
// Select from Mongo DB
// Delete from Mongo DB