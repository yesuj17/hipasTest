﻿angular
    .module('wemsManagementApp', ['chart.js'])
    .controller('WemsAnalysisController', ['$scope', '$http', WemsAnalysisController]);

function WemsAnalysisController($scope, $http) {
}