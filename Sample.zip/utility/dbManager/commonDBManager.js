﻿/* DB Manager */
var mongoose = require('mongoose');
var generateSchema = require('generate-schema');
var systemConfig = require('../../config/systemConfig');

// Connect to Mongo DB
module.exports.connect = function () {
    var mongoose = require('mongoose');
    mongoose.Promise = global.Promise;

    var db = mongoose.connection;
    db.on('error', console.error);
    db.once('open', function () {
        console.log("Connected to mongo server");
    });

    mongoose
        .connect(systemConfig.db.urls, function () {
            /* Dummy Function */
        })
        .then(() => {
            return true;
        })
        .catch(err => {
            console.error('App starting error:', err.stack);
            console.error("Failed to Connect Mongo DB!");
            process.exit(1);
        });
}

// Insert to Mongo DB
module.exports.insertMachineCycleData = function (data) {
    if (data) {
        var collectionName = data.title;
        var Schema = mongoose.Schema;
        var modelSchema = generateSchema.mongoose(data);
        var mongooseSchema = new Schema(modelSchema);
        var Model = mongoose.model(collectionName, mongooseSchema);
        var model = new Model(data.properties);
        model.save(function (err) {
            if (err) {
                console.error(err);
                return false;
            }
        });

        return true;
    }
}

// Update to Mongo DB
// Select from Mongo DB
// Delete from Mongo DB
