﻿/* WEMS Restful API Handler */
/* Restful API Handler Sample */
module.exports.sampleMethod = function (req, res) {
    res.render('./wems/sampleView');
}
