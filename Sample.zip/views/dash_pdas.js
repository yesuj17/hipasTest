﻿
/* PdAS Javascript */

/* OnLoad() call from index */
function pdas_OnLoad() {    

}
