﻿angular
    .module('wemsAnalysisApp', ['chart.js'])
    .controller('WemsAnalysisController', ['$scope', '$http', WemsAnalysisController]);

/* XXX TEST */
var canvas = document.getElementById('wemsPowerContent'),
    ctx = canvas.getContext('2d'),
    startingData = {
        labels: [0, 1],
        datasets: [
            {
                label: "DataSet 1",
                backgroundColor: "rgba(220, 220, 220, 0.5)",
                fillColor: "rgba(220,220,220,0.2)",
                strokeColor: "rgba(220,220,220,1)",
                pointColor: "rgba(220,220,220,1)",
                pointStrokeColor: "#fff",
                data: [0, 1]
            }
        ]
    };

var canvas1 = document.getElementById('wemsCycleTimeContent'),
    ctx1 = canvas1.getContext('2d'),
    startingData = {
        labels: [0, 1],
        datasets: [
            {
                label: "DataSet 1",
                backgroundColor: "rgba(220, 220, 220, 0.5)",
                fillColor: "rgba(220,220,220,0.2)",
                strokeColor: "rgba(220,220,220,1)",
                pointColor: "rgba(220,220,220,1)",
                pointStrokeColor: "#fff",
                data: [0, 1]
            }
        ]
    };

var config = {
    type: 'line',
    data: startingData,
};

var myLiveChart = new Chart(ctx, config);
var myLiveChart = new Chart(ctx1, config);

function WemsAnalysisController($scope, $http) {
    var vm = this;
}   
    