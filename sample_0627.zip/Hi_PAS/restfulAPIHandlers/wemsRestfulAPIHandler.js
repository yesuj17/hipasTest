﻿// WEMS Restful API Handler
var wemsDBManager = require('../utility/dbManager/wemsDBManager');
var machineAnalysisData = require('../models/wems/machineAnalysisData.json');

// GET Restful API Handler
module.exports.getAnalysisData = function (req, res) {
    if (!wemsDBManager) {
        return;
    }

    var startDate = new Date();
    startDate.setHours(0, 0, 0, 0);
    var endDate = new Date();
    endDate.setHours(23, 59, 59, 999);

    var period = {
        startDate: startDate,
        endDate: endDate
    }

    if (req.query.startDate && req.query.endDate) {
        period.startDate = new Date(req.query.startDate);
        period.endDate = new Date(req.query.endDate);
    }

    var machineCycleDataList = wemsDBManager.getMachineCycleData(period);
    res.data = generateAnalysisData(machineCycleDataList);
}

// POST Restful API Handler
// PUT Restful API Handler
// DELETE Restful API Handler

// WEMS Method
function generateAnalysisData(machineCycleDataList) {
    if (!machineCycleData) {
        return;
    }

    var machineAnalysisDataList = [];
    machineCycleDataList.forEach(generateAnalysisHandler);

    return machineAnalysisDataList;

    //////////////////////////////
    // Generate Analysis Handler
    function generateAnalysisHandler(machineCycleData) {
        var date = machineCycleData.TotalStartTime.setMinutes(0, 0, 0);
        var sc_No = machineCycleData.SC_No;
        var devicePowerData = calDeivcePowerData(machineCycleData);
        var deviceCycleTimeData = calDeivcePowerData(machineCycleData);
        var newDeviceData;

        if (machineAnalysisDataList.length !== 0) {
            var existAnalysisData = machineAnalysisDataList.find(checkAnalysisData, date);
            if (existAnalysisData) {
                var existDeviceData = machineAnalysisDataList.AnalysisData.find(checkDevice, sc_No);
                if (existDeviceData) {
                    existDeviceData.Power
                        = existDeviceData.Power + devicePowerData;
                    existDeviceData.CycleTime
                        = existDeviceData.CycleTime + deviceCycleTimeData;
                    return;
                }

                newDeviceData = {
                    "SC_No": sc_No,
                    "Power": devicePowerData,
                    "CycleTime": deviceCycleTimeData
                }

                existAnalysisData.AnalysisData.push(newDeviceData);
                return;
           }
        }

        var analysisData = JSON.parse(JSON.stringify(machineAnalysisData));
        analysisData.AnalysisDate = date;
        newDevice = {
            "SC_No": sc_No,
            "Power": devicePowerData,
            "CycleTime": deviceCycleTimeData
        }

        analysisData.AnalysisData.push(newDevice);
        machineAnalysisDataList.push(analysisData);
    }

    // Check Analysis Data
    function checkAnalysisData(analysisData, date) {
        if (analysisData.AnalysisDate === date) {
            return analysisData;
        }

        return;
    }

    // Check Device
    function checkDevice(deviceData, deviceID) {
        if (deviceData.SC_No === deviceID) {
            return deviceData;
        }

        return;
    }

    // Cal Device Power Data
    function calDeivcePowerData(machineCycleData) {
        var devicePowerData;

        machineCycleData.DrivingInfo.forEach(generateMotorPowerConsumptionHandler);
        machineCycleData.HoistingInfo.forEach(generateMotorPowerConsumptionHandler);
        machineCycleData.ForkInfo.forEach(generateMotorPowerConsumptionHandler);

        return devicePowerData;

        ///////////////////////////////////////////
        // Generate Motor Power Consumption Handler
        function generateMotorPowerConsumptionHandler(motorInfo) {
            var totalMotorPowerConsumption;
            /* XXX */
        }
    }

    // Cal Device Cycle Time Data
    function calDeviceCycleTimeData(machineCycleData) {
        var deviceCycleTime
            = machineCycleData.TotalEndTime - machineCycleData.TotalStartTime;

        return deviceCycleTime;
    }
}

