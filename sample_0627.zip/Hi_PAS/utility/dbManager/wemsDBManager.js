﻿var mongoose = require('mongoose');
var generateSchema = require('generate-schema');
var createMongooseSchema = require('json-schema-to-mongoose')

// Insert to Mongo DB
// Update to Mongo DB
// Select from Mongo DB
module.exports.getMachineCycleData = getMachineCycleData;

// Delete from Mongo DB

// WEMS DB Manager Function
// Get Machine Cycle Data
function getMachineCycleData(period) {
    var machineCycleData = require("../../models/pdas/machineCycleData.json");
    var machineCycleDataSchema = createMongooseSchema(machineCycleData, machineCycleData);
    var MachineCycleData;
    try {
        MachineCycleData = mongoose.model(machineCycleData.title);
    } catch (err) {
        if (err.name == 'MissingSchemaError')
            MachineCycleData = mongoose.model(machineCycleData.title, machineCycleDataSchema);
    }

    MachineCycleData.find()
        .and([{
            TotalStartTime: {
                $gte: period.startDate
            }
        }
            , {
                TotalEndTime: {
                    $lte: period.endDate
                }
            }
        ])
        .exec(function (err, docs) {
            if (err) {
                console.error(err);
                return false;
            }

            return docs;
        });

    return;
}
